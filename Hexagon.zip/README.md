game with hexagon map

==

achieve a desktop game for study and fun

with hexagon coordinate ...done

with map element        ...done

with keyboard control   ...undone

with hero and skill     ...undone

with map editor         ...undone

with equipment and card ...undone

with log record         ...undone

with server and client  ...undone

with chating            ...undone

with AI                 ...undone


a lot a lot to do .....

Enviroment: Qt5.0.2 + win8 and maybe will + python
